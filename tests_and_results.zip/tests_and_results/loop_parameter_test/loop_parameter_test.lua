--------------
--loop_parameter_test.lua
--------------------------

--tests done with the commands in this file:
    --whether exclude_player works on non-positional sounds (docs hint no, code hints at yes. If yes, make the hint in documentation clearer and more correct.)
    --whether positional,global,to_player,on_object sounds can be looped, and actually do loop.
--RESULTS:
--exclude_player ALSO works for non-positional, global sounds. As such, the current hint in the docs is misleading and has to be added to.
--looped sound works with global sound
--looped sound works with to_player sound
--looped sound works with pos sound: BUT! max_distance seems to be ignored? running 600 nodes away, it still is audible. needs followup tests on whether that only happens when player was already near, or anywhere no matter how far from the created sound. Also needs tests on whether maximum distance is actually followed with looped sounds.
--looped sound works with obj sound: BUT! max_distance seems to be ignored? Same as above.


---------------------------------------------------

--TODO: check if pos sound, object sound obeys max distance and if it is heard serverwide even if not close when it originates



--usage: check if 'exclude_player' is overruled by 'to_player' to the same player. test this with 'singleplayer', then 'singleplayer1'.

minetest.register_chatcommand("serverwide_sound_excluding_player", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local exclude_player=param
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{exclude_player=exclude_player})

        local rs=nil --returnString for chatcommand
        if exclude_player then
            rs="Played the sound to everyone except: "..exclude_player
        else 
            rs="No player parameter detected! Sound played to everyone."
        end
        return true, rs

    end
})

---------------------------------------------------

--usage: check if global sound can be looped

minetest.register_chatcommand("looped_global_sound", {
    privs={basic_privs=true}, 
    func=function(name,param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = 1,
            loop=true
            })

        local rs=nil --returnString for chatcommand
            rs="Played the sound globally with loop=true. Does it loop?"
        return true, rs

    end
})

---------------------------------------------------

--usage: check if to_player sound can be looped

minetest.register_chatcommand("looped_to_player_sound", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local my_to_player=param
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1,
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = 1,
            loop=true,
            to_player=my_to_player
            }
        )

        local rs=nil --returnString for chatcommand
        if my_to_player then
            rs="Played the sound to the player "..my_to_player.." with loop=true. Does it loop?"
        else
            rs="No player parameter was passed. Sound was played to noone..."
        end
        return true, rs

    end
})

---------------------------------------------------

---------------------------------------------------

--usage: check if pos sound can be looped. Go left/right/away to make certain the sound is locational and loudest at the origin. 
minetest.register_chatcommand("looped_pos_sound", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1,
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = 1,
            loop=true,
            pos=my_pos
            }
        )

        local rs=nil --returnString for chatcommand
        if to_player then
            rs="Played the sound at the pos of "..my_player.." with loop=true. Does it loop?"
        else
            rs="No player parameter was passed to fetch a pos. Sound was played to everyone!"
        end
        return true, rs

    end
})

---------------------------------------------------


--Following are the same tests, but with sound bound to an object instead of a pos.
--For this purpose, we spawn an object/entity at the next four commands' spots.

---------------------------------------------------

--Object Definition

local my_soundtest_entity_object_definition={

    physical = true,
    collide_with_objects = true,
    collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
    selectionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},	
    pointable = true,
    visual = "cube",
    visual_size = {x = 1, y = 1, z = 1},
    textures = {
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png"
    },
    use_texture_alpha = false,
    is_visible = true,
    nametag = "SOUND TEST ENTITY",
    static_save = true,
    damage_texture_modifier = "^[brighten",
    shaded = true,
    show_on_minimap = false,
}

--Entity Definition

local my_soundtest_entity_definition={
    initial_properties=my_soundtest_entity_object_definition,
    on_activate = function(self, staticdata, dtime_s) end,
    on_step = function(self, dtime, moveresult) end,
    on_punch = function(self, puncher, time_from_last_punch, tool_capabilities, dir) 
    self.object:remove()
    end,
    on_rightclick = function(self, clicker)
        local pos=self.object:get_pos()
        pos.x=pos.x+10
        pos.y=pos.y+5
        self.object:set_pos(pos)
    end,
    get_staticdata = function(self) end,
    _custom_field = "whatever",
}

--registering

minetest.register_entity("loop_parameter_test:sound_entity",my_soundtest_entity_definition)

---------------------------------------------------



--chat: /spawnentity loop_parameter_test:sound_entity 100 10 100
--lua: minetest.add_entity(pos, name, [staticdata])
--minetest.add_entity(pos,"loop_parameter_test:sound_entity")


---------------------------------------------------



---------------------------------------------------

--usage: check if pos sound can be looped. Create an entity/obj nearby, then use this. Go left/right/away to make certain the sound is locational and loudest at the origin

minetest.register_chatcommand("looped_obj_sound", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+1     --spawn it not inside the player.
        local target_obj=minetest.add_entity(my_pos,"loop_parameter_test:sound_entity")

        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1,
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = 1,
            loop=true,
            object=target_obj
            }
        )

        local rs=nil --returnString for chatcommand
        rs="Played the sound at the pos of the object we spawned near "..name.." with loop=true. Does it loop?"
        return true, rs

    end
})

---------------------------------------------------