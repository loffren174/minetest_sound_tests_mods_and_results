

if minetest then path=minetest.get_modpath("loop_parameter_test") end

dofile(path.."/loop_parameter_test.lua")