local path='.'
if minetest then path=minetest.get_modpath("sss_pitch_fade_gain_test") end

dofile(path.."/sss_pitch_fade_gain_test.lua")