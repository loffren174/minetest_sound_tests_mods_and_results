
-- sss_pitch_fade_gain_test.lua
--------------------------

--This tests if the SimpleSoundSpec parameters 'pitch' and 'fade' are used by the engine when playing node sounds with said sss defining them.
--For this purpose, several nodes will be registered:
--1: value not set
--2: value explicitly set to documented default
--3A,3B,3C: value set to higher value: default*x, where x can be 2,5,10
--4A,4B,4C: value set to lower value: default/x, where x can be 2,5,10

--Then, the nodes ingame can be punched to directly compare the sounds.
--Depending on which nodes sound different and which sound identical, the behavior can be reconstructed.
--Comparing 1 and 2, with the expected result being identical sounds, would indicate: the documented default is the one used when the value is omitted, OR any value is ignored
--Comparing (1 and 2)'s sounds with 3 and 4, with the expected result being different sounds between any of 3 and 4 and (1 and 2), would indicate: the value is actually used, and the default value is correctly set.

--This will be done once for pitch, and once for fade values, and once for gain values.

--Which means 24 blocks in total.

-----------------
--PITCH:

--TESTS:
--Do 1 and 2 sound the same?
--Do (1 and 2) and any of 3,4 sound the same? Do any of 3,4 sound the same?

--RESULTS:
--Yes, 1 and 2 sound the same. No others except (1 and 2) sound the same. This means the default is correctly documented, and is used when not explicitly defined, and the pitch is actually used.


--CONCLUSIONS:
--pitch works intended for in-engine use when specified in the SSS. The default value that is used when none is specified matches the lua documentation.



-----------------
--FADE:

--TESTS:
--Do 1 and 2 sound the same?
--Do (1 and 2) and any of 3,4 sound the same? Do any of 3,4 sound the same?

--RESULTS:
--No two nodes sound the same, except 1 and 2 (the undefined one and the one explicitly defined to default value). This means the default value is the same as the documented one.
--Note that while 0 is default for fade, very-small values mean the sound is almost entirely muffled - for example, fade=0.1 is barely audible, while fade=10 sounds very similar, but still more quiet, to fade=0 i.e. no fade cutoff. Fade values of 1-10 still are vary noticably more silent than Fade=0, for example. To get close to the sound of 'no fade' i.e. setting fade to 0, a very large value is required, perhaps 20 or higher.


--CONCLUSIONS:
--fade works intended for in-engine use when specified in the SSS. The default value that is used when none is specified matches the lua documentation. 
-- However, the INTENDED use of fade is not straightforward: while the default value is 0, meaning 'disabled', the actual 'identical to no fade' value seems to be 20 or higher, as anything lower will be noticably more silent (10,5,2,1,0.1...) which means that 0 has a special 'fade disabled' meaning, while the actual '0' value would make the sound completely inaudible, i.e. the opposite.

--------------------------

--GAIN:

--TESTS:
--Do 1 and 2 sound the same?
--Do (1 and 2) and any of 3,4 sound the same? Do any of 3,4 sound the same?

--RESULTS:
--all nodes 1,2,3A,3B,3C sound the same, while 4A,4B,4C sound notably more silent.


--CONCLUSIONS:
--gain works intended for in-engine use when specified in the SSS. The default value that is used when none is specified matches the lua documentation. 
--gain seems to be capped at 1, not getting any louder there. Below 1, the sound is approximately made more silent linearly to the value, i.e. 0.5 is something close to half as loud.

--------------------------

-----------------------------------------------------------------------------------------------------------------------

--PITCH NODE DEFINITIONS:


minetest.register_node("sss_pitch_fade_gain_test:pitch1_undefined", {
    description = "pitch1_undefined",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a"},
        place = {name = "mesecons_noteblock_a", gain = 1}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:pitch2_defined_default", {
    description = "pitch2_defined_default",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 1},
        place = {name = "mesecons_noteblock_a", gain = 1, pitch = 1}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:pitch3A_2", {
    description = "pitch3A_2",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 2},
        place = {name = "mesecons_noteblock_a", gain = 1, pitch = 2}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:pitch3B_5", {
    description = "pitch3B_5",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 5},
        place = {name = "mesecons_noteblock_a", gain = 1, pitch = 5}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:pitch3C_10", {
    description = "pitch3C_10",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 10},
        place = {name = "mesecons_noteblock_a", gain = 1, pitch = 10}
        }
    }
    )


    minetest.register_node("sss_pitch_fade_gain_test:pitch4A_0_5", {
        description = "pitch4A_0_5",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.5},
            place = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.5}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:pitch4B_0_2", {
        description = "pitch4B_0_2",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.2},
            place = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.2}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:pitch4C_0_1", {
        description = "pitch4C_0_1",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.1},
            place = {name = "mesecons_noteblock_a", gain = 1, pitch = 0.1}
            }
        }
        )



-----------------------------------------------------------------------------------------------------------------------

--FADE NODE DEFINITIONS:

minetest.register_node("sss_pitch_fade_gain_test:fade1_undefined", {
    description = "fade1_undefined",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a"},
        place = {name = "mesecons_noteblock_a", gain = 1}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:fade2_defined_default", {
    description = "fade2_defined_default",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, fade = 0},
        place = {name = "mesecons_noteblock_a", gain = 1, fade = 0}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:fade3A_2", {
    description = "fade3A_2",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, fade = 2},
        place = {name = "mesecons_noteblock_a", gain = 1, fade = 2}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:fade3B_5", {
    description = "fade3B_5",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, fade = 5},
        place = {name = "mesecons_noteblock_a", gain = 1, fade = 5}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:fade3C_10", {
    description = "fade3C_10",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1, fade = 10},
        place = {name = "mesecons_noteblock_a", gain = 1, fade = 10}
        }
    }
    )


    minetest.register_node("sss_pitch_fade_gain_test:fade4A_0_5", {
        description = "fade4A_0_5",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, fade = 0.5},
            place = {name = "mesecons_noteblock_a", gain = 1, fade = 0.5}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:fade4B_0_2", {
        description = "fade4B_0_2",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, fade = 0.2},
            place = {name = "mesecons_noteblock_a", gain = 1, fade = 0.2}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:fade4C_0_1", {
        description = "fade4C_0_1",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 1, fade = 0.1},
            place = {name = "mesecons_noteblock_a", gain = 1, fade = 0.1}
            }
        }
        )

    -----------------------------------------------------------------------------------------------------------------------

    --FADE NODE DEFINITIONS:

minetest.register_node("sss_pitch_fade_gain_test:gain1_undefined", {
    description = "gain1_undefined",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a"},
        place = {name = "mesecons_noteblock_a"}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:gain2_defined_default", {
    description = "gain2_defined_default",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 1},
        place = {name = "mesecons_noteblock_a", gain = 1}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:gain3A_2", {
    description = "gain3A_2",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 2},
        place = {name = "mesecons_noteblock_a", gain = 2}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:gain3B_5", {
    description = "gain3B_5",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 5},
        place = {name = "mesecons_noteblock_a", gain = 5}
        }
    }
    )

minetest.register_node("sss_pitch_fade_gain_test:gain3C_10", {
    description = "gain3C_10",
    groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
    tiles = {"mesecons_noteblock.png"},
    on_punch = function(pos, node, puncher) 
        end,
    sounds ={
        dig = {name = "mesecons_noteblock_a", gain = 10},
        place = {name = "mesecons_noteblock_a", gain = 10}
        }
    }
    )


    minetest.register_node("sss_pitch_fade_gain_test:gain4A_0_5", {
        description = "gain4A_0_5",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 0.5},
            place = {name = "mesecons_noteblock_a", gain = 0.5}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:gain4B_0_2", {
        description = "gain4B_0_2",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 0.2},
            place = {name = "mesecons_noteblock_a", gain = 0.2}
            }
        }
        )
    
    minetest.register_node("sss_pitch_fade_gain_test:gain4C_0_1", {
        description = "gain4C_0_1",
        groups = {snappy=2, choppy=2, oddly_breakable_by_hand=2},
        tiles = {"mesecons_noteblock.png"},
        on_punch = function(pos, node, puncher) 
            end,
        sounds ={
            dig = {name = "mesecons_noteblock_a", gain = 0.1},
            place = {name = "mesecons_noteblock_a", gain = 0.1}
            }
        }
        )



