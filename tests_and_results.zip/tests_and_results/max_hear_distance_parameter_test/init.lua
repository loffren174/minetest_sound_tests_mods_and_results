local path='.'
if minetest then path=minetest.get_modpath("max_hear_distance_parameter_test") end

dofile(path.."/max_hear_distance_parameter_test.lua")