--------------
--max_hear_distance_parameter_test.lua
--------------------------

--tests done with the commands in this file:
    --Test 1: check if default max_hear_distance is actually working and cutting off at precisely 32 nodes.
    --Test 2A,2B: when sound is locational at pos and not looped: is a custom max_hear_distance correctly followed? Is the default max_hear_distance followed when no custom one is applied? Versions: noise at x+10, noise at x+50
    --Test 3: same as Test 1, but with looped sound. Additionally: does the behavior of looped sounds unexpectedly change depending on whether the player was in the initial distance?
    --Test 4: same as Test 2, but with looped. Additionally: does the behavior of looped sounds unexpectedly change depending on whether the player was in the initial distance? Versions: noise at x+10, noise at x+50
    --Tests 5,6,7,8: same as Tests 1,2,3,4 but with sound bound to an entity (we spawn one at said position.) Additionally: What happens with looped sounds once the entity has moved/been removed/inactive? Versions: noise object at x+10, noise object at x+50


--RESULTS:
    --Test1: default value of max_hear_distance behaves as documented, cutting off at precisely 32nodes.
    --Tests 2A,2B: sound is correctly using custom max_hear_distance. Sounds with max_hear_distance lower than distance to player don't play.
    --NOTICE: Interestingly, sounds played 50 nodes away with any max_hear_distance >=50 are still more silent than sounds played at 10 nodes with a much lower max_hear_distance that is barely above 10. max_hear_distance has no effect whatsoever on the volume of the sound that is played.
    --Test3: default value of max_hear_distance when looped behaves as documented, WITH A TWIST: if player is outside initial range, they never hear the sound. BUT if player is inside initial range, they ALWAYS hear the looped sound at a minimum (~10%?) volume, NO MATTER how far they go away from the spot. When they come closer, the looped sound gets louder just as a normal positional sound.
    --Test4: custom values of max_hear_distance, as well as the default values, behave as documented, with the same twist as in Test 3.
    --Test5: default value of max_hear_distance when not-looped at object behaves as documented. Cleanly cuts off at 32 nodes.
    --Test6: custom values of max_hear_distance when not-looped at object behaves as documented. Cleanly cuts off at 32 nodes.
    --Test7: default value of max_hear_distance when looped behaves as documented, WITH THREE TWISTS: same twist as in test 3, and two more: if the object is removed, the looped sound continues in the same manner as if the object was still present at its last position. But if the object has moved and still exists, then the position where the sound gets louder again is updated.
    --Test8: custom values of max_hear_distance when looped behaves as documented, WITH THREE TWISTS: same twists as in test 7

--CONCLUSIONS:
    --the key determining whether a player hears a localized looped sound, or does not hear it at all, is the max_distance at sound creation. Coming closer later will not result in hearing the sound.
    --However, once the player was close enough to hear the initial sound, they will ALWAYS hear a looped sound with at least a minimum loudness of being 'barely in range', even when they go far away from the sound. When they come closer again to the origin, the looped sound still gets louder (and played louder at correct left-right sound direction) as normal.
    --so, players initially out of range of the looped sound will never hear it even when they come close, while players in the initial range of the looped sound will ALWAYS hear it with a minimum volume no matter where they are, or louder if they return closer to the sound's origin.
    --this behavior also holds true when playing sounds at an object.
    --looped sounds will continue looping in the behavior described above even when the object the original sound was played at is long gone/removed/unloaded/disabled.
    --as such, the 'loop' parameter does not overwrite the maximum_distance parameter, but adds three quirks to it - the center of the sound moving with the position of the object, the sound remaining alive at the last spot the object existed at even when the object has been removed, and always playing at a minimum volume to initially-hearing players, no matter how far they go away.
---------------------------------------------------







---------------------------------------------------
--Test 1: check if max_hear_distance default is actually 32 nodes:
--usage: check if default 'max_hear_distance' is actually at 32 nodes as intended. Play sound at arbitrary distance to player, check around the 32 nodes distance, above and below.
minetest.register_chatcommand("default_max_hear_distance_at_custom_distance", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound the custom nodes away from the player in x direction.
        local away=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+away

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos})

        local rs=nil --returnString for chatcommand
        if away then
            rs="Played the sound at x+ "..away.." of player position with default max_hear_distance. (Should be 32 nodes)"        else 
            rs="No distance parameter detected! Sound played at player position."
        end
        return true, rs

    end
})



---------------------------------------------------

--Test 2A:
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound. Test without giving a max_dist, and with a custom max_dist below, at, and over 10 nodes
minetest.register_chatcommand("positional_sound_10_nodes_away_with_custom_max_hear_distance", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound 10 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+10

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos,max_hear_distance=my_max_dist})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at x+10 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 2B:
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound. Test without giving a max_dist, and with a custom max_dist below, at, and over 50 nodes
minetest.register_chatcommand("positional_sound_50_nodes_away_with_custom_max_hear_distance", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound 50 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+50

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos,max_hear_distance=my_max_dist})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at x+50 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 3: check if max_hear_distance default is actually 32 nodes when looped (!):
--usage: check if default 'max_hear_distance' is actually at 32 nodes as intended when looping sound (!). Play sound at arbitrary distance to player, check around the 32 nodes distance, above and below.
minetest.register_chatcommand("default_max_hear_distance_at_custom_distance_loop", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound the custom nodes away from the player in x direction.
        local away=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+away

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos,loop=true})

        local rs=nil --returnString for chatcommand
        if away then
            rs="Played the sound at x+ "..away.." of player position, looped, with default max_hear_distance. (Should be 32 nodes)"        else 
            rs="No distance parameter detected! Sound played at player position."
        end
        return true, rs

    end
})



---------------------------------------------------

--Test 4A:
--usage: check if custom 'max_hear_distance' is obeyed by locational looped (!) sound. Test without giving a max_dist, and with a custom max_dist below, at, and over 10 nodes
minetest.register_chatcommand("positional_sound_10_nodes_away_with_custom_max_hear_distance_looped", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound 10 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+10

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos,max_hear_distance=my_max_dist,loop=true})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at x+10 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 4B:
--usage: check if custom 'max_hear_distance' is obeyed by locational looped (!) sound. Test without giving a max_dist, and with a custom max_dist below, at, and over 50 nodes
minetest.register_chatcommand("positional_sound_50_nodes_away_with_custom_max_hear_distance_looped", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound 50 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+50

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{pos=my_pos,max_hear_distance=my_max_dist,loop=true})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at x+50 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------


--Following are the same tests, but with sound bound to an object instead of a pos.
--For this purpose, we spawn an object/entity at the next four commands' spots.

---------------------------------------------------

--Object Definition

local my_soundtest_entity_object_definition={

    physical = true,
    collide_with_objects = true,
    collisionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
    selectionbox = {-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},	
    pointable = true,
    visual = "cube",
    visual_size = {x = 1, y = 1, z = 1},
    textures = {
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png",
            "mesecons_noteblock.png"
    },
    use_texture_alpha = false,
    is_visible = true,
    nametag = "SOUND TEST ENTITY",
    static_save = true,
    damage_texture_modifier = "^[brighten",
    shaded = true,
    show_on_minimap = false,
}

--Entity Definition

local my_soundtest_entity_definition={
    initial_properties=my_soundtest_entity_object_definition,
    on_activate = function(self, staticdata, dtime_s) end,
    on_step = function(self, dtime, moveresult) end,
    on_punch = function(self, puncher, time_from_last_punch, tool_capabilities, dir) 
    self.object:remove()
    end,
    on_rightclick = function(self, clicker)
        local pos=self.object:get_pos()
        pos.x=pos.x+10
        pos.y=pos.y+5
        self.object:set_pos(pos)
    end,
    get_staticdata = function(self) end,
    _custom_field = "whatever",
}

--registering

minetest.register_entity("max_hear_distance_parameter_test:sound_entity",my_soundtest_entity_definition)

---------------------------------------------------



--chat: /spawnentity max_hear_distance_parameter_test:sound_entity 100 10 100
--lua: minetest.add_entity(pos, name, [staticdata])
--minetest.add_entity(pos,"max_hear_distance_parameter_test:sound_entity")


---------------------------------------------------


--Test 5: same as test 1, but when played at object.
--usage: check if default 'max_hear_distance' is actually at 32 nodes as intended. Play sound at arbitrary distance to player, check around the 32 nodes distance, above and below.
minetest.register_chatcommand("default_max_hear_distance_at_custom_distance_object", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound the custom nodes away from the player in x direction.
        local away=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+away

        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{object=my_entity})

        local rs=nil --returnString for chatcommand
        if away then
            rs="Played the sound at object at x+ "..away.." of player position with default max_hear_distance. (Should be 32 nodes)"        else 
            rs="No distance parameter detected! Sound played at object at player position."
        end
        return true, rs

    end
})


---------------------------------------------------

--Test 6A: same as test 2A, but when played at object.
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound at object. Test without giving a max_dist, and with a custom max_dist below, at, and over 10 nodes
minetest.register_chatcommand("positional_sound_10_nodes_away_with_custom_max_hear_distance_object", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound at entity 10 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+10

        
        --spawn entity at pos:
        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{object=my_entity,max_hear_distance=my_max_dist})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at object at x+10 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played at object with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 6B: same as test 2B, but when played at object.
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound at object. Test without giving a max_dist, and with a custom max_dist below, at, and over 50 nodes

minetest.register_chatcommand("positional_sound_50_nodes_away_with_custom_max_hear_distance_object", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound at entity 50 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+50

        
        --spawn entity at pos:
        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{object=my_entity,max_hear_distance=my_max_dist})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at object at x+50 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played at object with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 7: same as test 3, but when played at object.
--usage: check if default 'max_hear_distance' is actually at 32 nodes as intended when looping sound (!) at object. Play sound at object at arbitrary distance to player, check around the 32 nodes distance, above and below.
minetest.register_chatcommand("default_max_hear_distance_at_custom_distance_object_looped", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound at object the custom nodes away from the player in x direction.
        local away=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+away

        
        --spawn entity at pos:
        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
        },{object=my_entity,loop=true})

        local rs=nil --returnString for chatcommand
        if away then
            rs="Played the sound at object x+ "..away.." of player position, looped, with default max_hear_distance. (Should be 32 nodes)"        else 
            rs="No distance parameter detected! Sound played at object at player position."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 8A: same as test 4A, but when played at object.
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound at object. Test without giving a max_dist, and with a custom max_dist below, at, and over 10 nodes
minetest.register_chatcommand("positional_sound_10_nodes_away_with_custom_max_hear_distance_object_looped", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound at entity 10 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+10

        
        --spawn entity at pos:
        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{object=my_entity,max_hear_distance=my_max_dist,loop=true})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at object at x+10 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played at object with default of 32."
        end
        return true, rs

    end
})

---------------------------------------------------

--Test 8B: same as test 4B, but when played at object.
--usage: check if custom 'max_hear_distance' is obeyed by locational not-looped sound at object. Test without giving a max_dist, and with a custom max_dist below, at, and over 50 nodes

minetest.register_chatcommand("positional_sound_50_nodes_away_with_custom_max_hear_distance_object_looped", {
    privs={basic_privs=true}, 
    func=function(name,param)

        --we initiate the sound at entity 50 nodes away from the player.
        local my_max_dist=tonumber(param)
        local my_player=minetest.get_player_by_name(name)
        local my_pos=my_player:get_pos()
        my_pos.x=my_pos.x+50

        
        --spawn entity at pos:
        local my_entity=minetest.add_entity(my_pos,"max_hear_distance_parameter_test:sound_entity")

        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch=1,
           },{object=my_entity,max_hear_distance=my_max_dist,loop=true})

        local rs=nil --returnString for chatcommand
        if my_max_dist then
            rs="Played the sound at object at x+50 of player position with max_hear_distance of: "..my_max_dist
        else 
            rs="No max_hear_distance parameter detected! Sound played at object with default of 32."
        end
        return true, rs

    end
})


---------------------------------------------------

