--------------
--gain_parameter_test.lua
--------------------------

--RESULTS:

---------------------------------------------------




--varying the gain in the SimpleSoundSpec table. We specify no parameter table, so it uses defaults.

minetest.register_chatcommand("gain_vary_SSS", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_gain=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = custom_gain or 1,
            pitch=1
           })


        local rs=nil --returnString for chatcommand
        if custom_gain then
            rs="Played the sound with detected gain parameter: "..custom_gain
        else 
            rs="No gain parameter detected! Sound played with gain '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--we set a fixed SSS gain at the default, and vary the gain in the 'sound parameters' table:

minetest.register_chatcommand("gain_vary_SP", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_gain=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = custom_gain
            })


        local rs=nil --returnString for chatcommand
        if custom_gain then
            rs="Played the sound with detected gain parameter: "..custom_gain
        else 
            rs="No gain parameter detected! Sound played with gain '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--varying the gain in the 'sound parameters' table with NO gain specified in SSS:
--identical to setting gain in SSS to the default '1', but just making sure.
--indeed, this yields identical results to gain_vary_SP

minetest.register_chatcommand("gain_vary_SP_no_SSS_gain", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_gain=tonumber(param)
        
        minetest.sound_play(
            "mesecons_noteblock_a",
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = custom_gain
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_gain then
            rs="Played the sound with detected gain parameter: "..custom_gain
        else 
            rs="No gain parameter detected! Sound played with gain '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

---------------------------------------------------

--if the gain set in SSS is truly irrelevant, both when used alone and when used with SP gain, 
--then the following will sound identical to the functions gain_vary_SP and gain_vary_SP_no_SSS.
--again, this is just doublechecking that in no case whatsoever the SSS gain value is used.

minetest.register_chatcommand("gain_vary_SP_double_SSS_gain", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_gain=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            pitch = 1,
            gain = 2       --note that this should cause it sound different if it has an impact!
            },
            {
            pitch = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            gain = custom_gain
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_gain then
            rs="Played the sound with detected gain parameter: "..custom_gain
        else 
            rs="No gain parameter detected! Sound played with gain '1' instead. Please put in a number."
        end
        return true, rs

    end
})