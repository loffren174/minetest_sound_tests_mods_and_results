

if minetest then path=minetest.get_modpath("gain_parameter_test") end

dofile(path.."/gain_parameter_test.lua")