

if minetest then path=minetest.get_modpath("fade_parameter_test") end

dofile(path.."/fade_parameter_test.lua")