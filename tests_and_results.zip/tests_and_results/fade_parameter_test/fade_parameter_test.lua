--------------
--fade_parameter_test.lua
--------------------------


--TESTS:
--1: varying SimpleSoundSpec (SSS) 'fade' param while providing no SP 'fade'. Check if it sounds different. This also checks if default value of SP is same as documented.
--2: varying Sound Parameters (SP) 'fade' param while providing no SSS 'fade'. Check if it sounds different.
--3: varying SP 'fade' with default 'SSS' fade explicitly set. This checks if the default value of SSS is same as documented.
--4: varying SP 'fade' with double the default 'SSS'. This checks if SSS value, or its default, is actually used, by the listener comparing the resulting sounds with equal parameters of the commands no_SSS_fade and fade_vary_SP (which sets the default SSS fade)



--RESULTS:
--1: varying SSS 'fade' has no audible effect. BUT: setting a fade of '1' is clearly not the default. Default is no fade at all, i.e. 0 or anything <0.
--2: varying SP 'fade' has a clear audible effect. good values to test: 0.1,1,10,20,50
--3: sounds identical to setting no explicit 'SSS' fade. This indicates the SSS default value has either: no effect, or is applied always, or works correctly. Test 4 will clarify.
--4: setting the doubled value of 'SSS' sounds identical to setting the default value. This confirms that the SSS 'fade' is not applied in any case whatsoever, not even the default.

--CONCLUSION:
--SSS 'fade' parameter is completely ignored, no matter whether it's explicitly set or not. 
--SP 'fade' parameter is used, leading to clearly different audio.
--The default value of SP's 'fade' parameter is 0 as suggested by the code.
--The 'fade' parameter of SP works as expected.


---------------------------------------------------


--varying the fade in the SimpleSoundSpec table. We specify no parameter table, so it uses defaults.

minetest.register_chatcommand("fade_vary_SSS", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_fade=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            fade = custom_fade or 1
           })


        local rs=nil --returnString for chatcommand
        if custom_fade then
            rs="Played the sound with detected fade parameter: "..custom_fade
        else 
            rs="No fade parameter detected! Sound played with fade '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--we set a fixed SSS fade at the default, and vary the fade in the 'sound parameters' table:

minetest.register_chatcommand("fade_vary_SP", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_fade=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            fade = 1
            },
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            fade = custom_fade
            })


        local rs=nil --returnString for chatcommand
        if custom_fade then
            rs="Played the sound with detected fade parameter: "..custom_fade
        else 
            rs="No fade parameter detected! Sound played with fade '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--varying the fade in the 'sound parameters' table with NO fade specified in SSS:
--identical to setting fade in SSS to the default '1', but just making sure.
--indeed, this yields identical results to fade_vary_SP

minetest.register_chatcommand("fade_vary_SP_no_SSS_fade", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_fade=tonumber(param)
        
        minetest.sound_play(
            "mesecons_noteblock_a",
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            fade = custom_fade
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_fade then
            rs="Played the sound with detected fade parameter: "..custom_fade
        else 
            rs="No fade parameter detected! Sound played with fade '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

---------------------------------------------------

--if the fade set in SSS is truly irrelevant, both when used alone and when used with SP fade, 
--then the following will sound identical to the functions fade_vary_SP and fade_vary_SP_no_SSS.
--again, this is just doublechecking that in no case whatsoever the SSS fade value is used.

minetest.register_chatcommand("fade_vary_SP_double_SSS_fade", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_fade=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            fade = 2       --note that this should cause it sound different if it has an impact!
            },
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            fade = custom_fade
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_fade then
            rs="Played the sound with detected fade parameter: "..custom_fade
        else 
            rs="No fade parameter detected! Sound played with fade '1' instead. Please put in a number."
        end
        return true, rs

    end
})