

if minetest then path=minetest.get_modpath("pitch_parameter_test") end

dofile(path.."/pitch_parameter_test.lua")