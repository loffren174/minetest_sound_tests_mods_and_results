--------------
--pitch_parameter_test.lua
--------------------------

--RESULTS:
--the parameter 'pitch' in SimpleSoundSpec is COMPLETELY ignored.
--this can be tested by inputting any number in the chat command pitch_vary_SSS: the resulting sound will be identical no matter the value.

--the parameter 'pitch' in the parameter table (second argument to minetest.sound_play) is fully functional.
--this can be tested by inputting any number in the chat command pitch_vary_SP: the resulting sound will be very different depending on the pitch value.

--setting NO SSS 'pitch' at all is the same as setting it to ANY value.
--this can be tested by inputting any number in the chat command pitch_vary_SP and comparing it to the result with the same parameter in the command pitch_vary_SP_no_SSS_pitch

--even when combining both pitch values, any change to the pitch variable of SimpleSoundSpec has no effect on the result whatsoever. 
--This is tested by comparing the sound of pitch_vary_SP_double_SSS_pitch and pitch_vary_SP, they should sound identical with same pitch values.


--all of this can be tested by using any values between 0.05 and 100 as pitch values.
--recommended values: 0,0.1,0.5,0.8,1,2,5,10,20,50
--all these values will sound completely identical i.e. are not having any effect when setting the value of 'pitch' within SimpleSoundSpec,
--but they will have a clear effect and sound quite different if you set the value of 'pitch' within the sound-parameter table.

--CONCLUSION:
--The parameter 'pitch' in the SimpleSoundSpec is completely ignored.
--The parameter 'pitch' in the Sound Parameter table is fully functional.


---------------------------------------------------




--varying the pitch in the SimpleSoundSpec table. We specify no parameter table, so it uses defaults.

minetest.register_chatcommand("pitch_vary_SSS", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_pitch=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = custom_pitch or 1
           })


        local rs=nil --returnString for chatcommand
        if custom_pitch then
            rs="Played the sound with detected pitch parameter: "..custom_pitch
        else 
            rs="No pitch parameter detected! Sound played with pitch '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--we set a fixed SSS pitch at the default, and vary the pitch in the 'sound parameters' table:

minetest.register_chatcommand("pitch_vary_SP", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_pitch=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 1
            },
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            pitch = custom_pitch
            })


        local rs=nil --returnString for chatcommand
        if custom_pitch then
            rs="Played the sound with detected pitch parameter: "..custom_pitch
        else 
            rs="No pitch parameter detected! Sound played with pitch '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

--varying the pitch in the 'sound parameters' table with NO pitch specified in SSS:
--identical to setting pitch in SSS to the default '1', but just making sure.
--indeed, this yields identical results to pitch_vary_SP

minetest.register_chatcommand("pitch_vary_SP_no_SSS_pitch", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_pitch=tonumber(param)
        
        minetest.sound_play(
            "mesecons_noteblock_a",
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            pitch = custom_pitch
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_pitch then
            rs="Played the sound with detected pitch parameter: "..custom_pitch
        else 
            rs="No pitch parameter detected! Sound played with pitch '1' instead. Please put in a number."
        end
        return true, rs

    end
})

---------------------------------------------------

---------------------------------------------------

--if the pitch set in SSS is truly irrelevant, both when used alone and when used with SP pitch, 
--then the following will sound identical to the functions pitch_vary_SP and pitch_vary_SP_no_SSS.
--again, this is just doublechecking that in no case whatsoever the SSS pitch value is used.

minetest.register_chatcommand("pitch_vary_SP_double_SSS_pitch", {
    privs={basic_privs=true}, 
    func=function(name,param)

        local custom_pitch=tonumber(param)
        
        minetest.sound_play({
            name = "mesecons_noteblock_a", 
            gain = 1,
            pitch = 2       --note that this should cause it sound different if it has an impact!
            },
            {
            gain = 1.0,   -- default
            fade = 0.0,   -- default, change to a value > 0 to fade the sound in
            pitch = custom_pitch
            }
        )

        local rs=nil --returnString for chatcommand
        if custom_pitch then
            rs="Played the sound with detected pitch parameter: "..custom_pitch
        else 
            rs="No pitch parameter detected! Sound played with pitch '1' instead. Please put in a number."
        end
        return true, rs

    end
})